import javax.swing.*;
import java.io.IOException;
import java.nio.file.*;
import java.util.List;
import java.util.stream.Stream;

public class FileLister
{
    private JTextArea textArea;
    private JLabel statusLabel;

    public FileLister(JTextArea textArea, JLabel statusLabel)
    {
        this.textArea = textArea;
        this.statusLabel = statusLabel;
    }

    public void listFiles(Path path)
    {
        try (Stream<Path> stream = Files.walk(path))
        {
            List<String> filesList = stream.map(Path::toString).toList();
            for (String file : filesList)
            {
                textArea.append(file + "\n");
            }
            statusLabel.setText("Listing complete.");
        } catch (IOException e)
        {
            textArea.append("Error listing files: " + e.getMessage() + "\n");
            statusLabel.setText("Error occurred.");
        }
    }
}
