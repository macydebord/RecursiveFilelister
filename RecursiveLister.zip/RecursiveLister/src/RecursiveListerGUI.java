import javax.swing.*;
import java.awt.*;
import java.io.File;

public class RecursiveListerGUI
{
    private JFrame frame;
    private JTextArea textArea;
    private JButton startButton;
    private JButton quitButton;
    private JLabel statusLabel;
    private FileLister fileLister;

    public RecursiveListerGUI()
    {
        frame = new JFrame("Recursive Lister");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(600, 400);

        textArea = new JTextArea();
        JScrollPane scrollPane = new JScrollPane(textArea);
        frame.getContentPane().add(scrollPane, BorderLayout.CENTER);

        startButton = new JButton("Start");
        startButton.addActionListener(e -> startListing());

        quitButton = new JButton("Quit");
        quitButton.addActionListener(e -> System.exit(0));

        JPanel buttonPanel = new JPanel();
        buttonPanel.add(startButton);
        buttonPanel.add(quitButton);
        frame.getContentPane().add(buttonPanel, BorderLayout.SOUTH);

        statusLabel = new JLabel(" ");
        frame.getContentPane().add(statusLabel, BorderLayout.NORTH);

        fileLister = new FileLister(textArea, statusLabel);

        frame.setVisible(true);
    }

    private void startListing()
    {
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
        int returnValue = fileChooser.showOpenDialog(frame);
        if (returnValue == JFileChooser.APPROVE_OPTION)
        {
            File selectedDirectory = fileChooser.getSelectedFile();
            textArea.setText("");
            fileLister.listFiles(selectedDirectory.toPath());
        }
    }
}

