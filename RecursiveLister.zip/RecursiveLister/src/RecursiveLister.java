import javax.swing.*;

public class RecursiveLister
{
    public static void main(String[] args)
    {
        SwingUtilities.invokeLater(RecursiveListerGUI::new);
    }
}
